// قطعه‌رسان — prototype interactions
(function () {
  'use strict';

  // Vehicle chips (home)
  document.querySelectorAll('.quickpick .chip').forEach(function (chip) {
    chip.addEventListener('click', function () {
      document.querySelectorAll('.quickpick .chip').forEach(function (c) {
        c.classList.remove('on');
      });
      chip.classList.add('on');
    });
  });

  // Quantity box (product page)
  var qtyInput = document.getElementById('qty-input');
  var faDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

  function toFa(n) {
    return String(n).replace(/[0-9]/g, function (d) { return faDigits[+d]; });
  }
  function fromFa(s) {
    return String(s).replace(/[۰-۹]/g, function (d) { return String(faDigits.indexOf(d)); })
                    .replace(/[^0-9]/g, '');
  }
  function getQty() {
    if (!qtyInput) return 1;
    var n = parseInt(fromFa(qtyInput.value), 10);
    if (isNaN(n) || n < 1) n = 1;
    if (n > 99) n = 99;
    return n;
  }
  function setQty(n) {
    if (qtyInput) qtyInput.value = toFa(n);
  }

  var minus = document.getElementById('qty-minus');
  var plus = document.getElementById('qty-plus');
  if (minus) minus.addEventListener('click', function () { setQty(Math.max(1, getQty() - 1)); });
  if (plus) plus.addEventListener('click', function () { setQty(Math.min(99, getQty() + 1)); });

  // data-qty buttons (alt product page markup)
  document.querySelectorAll('[data-qty]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      setQty(Math.min(99, Math.max(1, getQty() + parseInt(btn.getAttribute('data-qty'), 10))));
    });
  });

  // Add to cart badge
  var addBtn = document.getElementById('add-cart') || document.getElementById('add-to-cart');
  var cartBadge = document.getElementById('cart-count') || document.getElementById('cart-badge');
  if (addBtn) {
    var count = 0;
    addBtn.addEventListener('click', function () {
      count += getQty();
      if (cartBadge) cartBadge.textContent = toFa(count);
      var prev = addBtn.textContent;
      addBtn.textContent = '✓ به سبد اضافه شد';
      addBtn.style.background = '#1F9D55';
      setTimeout(function () {
        addBtn.textContent = prev;
        addBtn.style.background = '';
      }, 1500);
    });
  }

  // Search forms — prototype only
  document.querySelectorAll('.searchbox, .search-box').forEach(function (f) {
    f.addEventListener('submit', function (e) { e.preventDefault(); });
  });
})();
